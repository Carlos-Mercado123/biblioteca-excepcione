package Aplicacion;

import Clases.Libro;
import Clases.TextPrompt;
import java.awt.Color;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class Formulario extends javax.swing.JFrame {
    //Designed by:Piero Castañeda
    Libro objLi;
    DefaultListModel moLibro, moEditorial, moClase, moAño, moPaginas, moCosto;
    DefaultListModel moEstadisticas;

    public Formulario() {
        initComponents();
        iniciargraficos();
        llenaEditorial();
        llenaClase();
        cargaModelos();
    }

    void iniciargraficos() {
        setResizable(false);
        setLocationRelativeTo(null);
        Color color1 = new Color(200, 200, 200);
        TextPrompt prueba = new TextPrompt("Ingrese el nombre del libro", txtLibro);
        TextPrompt prueba1 = new TextPrompt("Año", txtAño);
        TextPrompt prueba2 = new TextPrompt("Paginas", txtPaginas);
        TextPrompt prueba3 = new TextPrompt("Costo", txtCosto);
        btnsalir.setOpaque(false);
        btnsalir.setBackground(new Color(0, 0, 0, 0));
       
    }

    void cargaModelos() {
        moLibro = new DefaultListModel();
        moEditorial = new DefaultListModel();
        moClase = new DefaultListModel();
        moAño = new DefaultListModel();
        moPaginas = new DefaultListModel();
        moCosto = new DefaultListModel();
        moEstadisticas = new DefaultListModel();
        lstLibro.setModel(moLibro);
        lstEditorial.setModel(moEditorial);
        lstClase.setModel(moClase);
        lstAño.setModel(moAño);
        lstPaginas.setModel(moPaginas);
        lstCosto.setModel(moCosto);
        lstEstadisticas.setModel(moEstadisticas);
    }

    void llenaModelos() {
        moLibro.addElement(objLi.getNombre());
        moEditorial.addElement(objLi.getEditorial());
        moClase.addElement(objLi.getClase());
        moAño.addElement(objLi.getAño());
        moPaginas.addElement(objLi.getPaginas());
        moCosto.addElement(objLi.getCosto());
    }

    void llenaEditorial() {
        cboEditorial.addItem("A");
        cboEditorial.addItem("B");
        cboEditorial.addItem("C");
    }

    void llenaClase() {
        cboClase.addItem("Programacion");
        cboClase.addItem("Analisis");
        cboClase.addItem("Diseño");
    }

    String getLibro() {
        return txtLibro.getText();
    }

    String getEditorial() {
        return String.valueOf(cboEditorial.getSelectedItem());
    }

    String getClase() {
        return String.valueOf(cboClase.getSelectedItem());
    }

    int getAño() {
        return Integer.parseInt(txtAño.getText());
    }

    int getPaginas() {
        return Integer.parseInt(txtPaginas.getText());
    }

    double getCosto() {
        return Double.parseDouble(txtCosto.getText());
    }

    public void limpiar() {
        txtLibro.setText("");
        txtAño.setText("");
        txtPaginas.setText("");
        txtCosto.setText("");
        cboEditorial.setSelectedIndex(0);
        cboClase.setSelectedIndex(0);
    }
    
    public void limpiargeneral(){
        
        DefaultListModel model = (DefaultListModel)lstLibro.getModel();
        DefaultListModel model1 = (DefaultListModel)lstEditorial.getModel();
        DefaultListModel model2 = (DefaultListModel)lstClase.getModel();
        DefaultListModel model3 = (DefaultListModel)lstAño.getModel();
        DefaultListModel model4 = (DefaultListModel)lstPaginas.getModel();
        DefaultListModel model5 = (DefaultListModel)lstCosto.getModel();
        DefaultListModel model6 = (DefaultListModel)lstEstadisticas.getModel();
        
        model.clear();
        model1.clear();
        model2.clear();
        model3.clear();
        model4.clear();
        model5.clear();
        model6.clear();
        
        txtLibro.setText("");
        txtAño.setText("");
        txtPaginas.setText("");
        txtCosto.setText("");
        cboEditorial.setSelectedIndex(0);
        cboClase.setSelectedIndex(0);
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtLibro = new javax.swing.JTextField();
        cboEditorial = new javax.swing.JComboBox<>();
        cboClase = new javax.swing.JComboBox<>();
        txtAño = new javax.swing.JTextField();
        txtPaginas = new javax.swing.JTextField();
        txtCosto = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstEditorial = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstClase = new javax.swing.JList<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstAño = new javax.swing.JList<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        lstPaginas = new javax.swing.JList<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        lstCosto = new javax.swing.JList<>();
        jScrollPane6 = new javax.swing.JScrollPane();
        lstEstadisticas = new javax.swing.JList<>();
        btnagregar = new javax.swing.JButton();
        btnestadistica = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        lstLibro = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        btnsalir = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        lblfondo = new javax.swing.JLabel();
        lbllibro2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtLibro.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        txtLibro.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos de Libro", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        txtLibro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLibroKeyTyped(evt);
            }
        });
        getContentPane().add(txtLibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 360, 70));

        cboEditorial.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        cboEditorial.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tipo de Editorial", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        cboEditorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboEditorialActionPerformed(evt);
            }
        });
        getContentPane().add(cboEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 80, 150, -1));

        cboClase.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        cboClase.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Clase de Libro", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        getContentPane().add(cboClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 80, 180, -1));

        txtAño.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        txtAño.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Año de Edicion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        getContentPane().add(txtAño, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 100, -1));

        txtPaginas.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        txtPaginas.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Paginas", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        getContentPane().add(txtPaginas, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 100, -1));

        txtCosto.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        txtCosto.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Costo", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        getContentPane().add(txtCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 100, -1));

        lstEditorial.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tipo", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        lstEditorial.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane1.setViewportView(lstEditorial);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 50, -1));

        lstClase.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Clases", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        lstClase.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane2.setViewportView(lstClase);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 230, 150, -1));

        lstAño.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Año", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        lstAño.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane3.setViewportView(lstAño);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 230, 100, -1));

        lstPaginas.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Paginas", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        lstPaginas.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane4.setViewportView(lstPaginas);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 230, 70, -1));

        lstCosto.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Costo", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        lstCosto.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane5.setViewportView(lstCosto);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 230, 110, -1));

        lstEstadisticas.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane6.setViewportView(lstEstadisticas);

        getContentPane().add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, 770, 154));

        btnagregar.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        btnagregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagenesBLEXPO/mas.png"))); // NOI18N
        btnagregar.setText("Agregar");
        btnagregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnagregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnagregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 170, 150, -1));

        btnestadistica.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        btnestadistica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagenesBLEXPO/analisis.png"))); // NOI18N
        btnestadistica.setText("Estadisticas");
        btnestadistica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnestadisticaActionPerformed(evt);
            }
        });
        getContentPane().add(btnestadistica, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 390, 200, -1));

        lstLibro.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        lstLibro.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        jScrollPane7.setViewportView(lstLibro);

        getContentPane().add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 240, -1));

        jLabel1.setBackground(new java.awt.Color(255, 51, 51));
        jLabel1.setFont(new java.awt.Font("Apple Braille", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BIBLIOTECA");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 240, 40));

        btnsalir.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        btnsalir.setForeground(new java.awt.Color(255, 255, 255));
        btnsalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagenesBLEXPO/icons8-salida-25.png"))); // NOI18N
        btnsalir.setText("Salir");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 380, 110, 50));

        btnlimpiar.setFont(new java.awt.Font("Apple Braille", 0, 14)); // NOI18N
        btnlimpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagenesBLEXPO/limpiar.png"))); // NOI18N
        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnlimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 380, 120, 40));

        lblfondo.setFont(new java.awt.Font("Apple Braille", 0, 18)); // NOI18N
        lblfondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagenesBLEXPO/guita.jpg"))); // NOI18N
        getContentPane().add(lblfondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, -1));

        lbllibro2.setFont(new java.awt.Font("Apple Braille", 1, 18)); // NOI18N
        lbllibro2.setForeground(new java.awt.Color(0, 102, 102));
        lbllibro2.setText("Datos del libro");
        getContentPane().add(lbllibro2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 200, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnagregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnagregarActionPerformed
        try {
            objLi = new Libro(getLibro(), getEditorial(), getClase(),
                    getAño(), getPaginas(), getCosto());
            llenaModelos();
            limpiar();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error en la Aplicacion " + ex.getMessage());
        }
    }//GEN-LAST:event_btnagregarActionPerformed

    private void btnestadisticaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnestadisticaActionPerformed
        try {
            moEstadisticas.clear();
            moEstadisticas.addElement(
                    "Numero de Libro de Análisis de la Editorial B es: " + objLi.getTAnalisis());
            int mayor = Integer.MIN_VALUE;
            int pos = 0;
            for (int i = 0; i < moLibro.getSize(); i++) {
                if (Integer.parseInt(moAño.elementAt(i).
                        toString()) > mayor) {
                    mayor = Integer.parseInt(moAño.elementAt(i).toString());
                    pos = i;
                }
            }
            moEstadisticas.addElement(
                    "Libro con el año de edición más reciente: " + moLibro.getElementAt(pos));
            int menor = Integer.MAX_VALUE;
            for (int i = 0; i < moLibro.getSize(); i++) {
                if (Integer.parseInt(moPaginas.elementAt(i).
                        toString()) < menor) {
                    menor = Integer.parseInt(moPaginas.elementAt(i).toString());
                    pos = i;
                }
            }
            moEstadisticas.addElement(
                    "Editorial con libro de menor pagina es: " + moEditorial.getElementAt(pos));
            double mayorCosto = Double.MIN_VALUE;
            for (int i = 0; i < moLibro.getSize(); i++) {
                if (Double.parseDouble(moCosto.elementAt(i)
                        .toString()) > mayorCosto) {
                    mayorCosto = Double.parseDouble(moCosto.elementAt(i)
                            .toString());
                    pos = i;
                }
            }
            moEstadisticas.addElement("Libro con mayor costo es:  " + moLibro.getElementAt(pos));

            bloquear();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error en la Aplicacion " + ex.getMessage());
        }
    }//GEN-LAST:event_btnestadisticaActionPerformed

    public void bloquear() {
        txtLibro.setEditable(false);
        txtAño.setEditable(false);
        txtPaginas.setEditable(false);
        txtCosto.setEditable(false);
        cboEditorial.setEnabled(false);
        cboClase.setEnabled(false);
        btnagregar.setEnabled(false);
        btnestadistica.setEnabled(false);

    }

    public void desbloquear() {
        txtLibro.setEditable(true);
        txtAño.setEditable(true);
        txtPaginas.setEditable(true);
        txtCosto.setEditable(true);
        cboEditorial.setEnabled(true);
        cboClase.setEnabled(true);
        btnagregar.setEnabled(true);
        btnestadistica.setEnabled(true);

    }

    private void txtLibroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtLibroKeyTyped
        String texto = txtLibro.getText();
        char[] cadena = texto.toCharArray();
        for (int a = 0; a < texto.length() - 1; a++) {
            cadena[0] = Character.toUpperCase(cadena[0]);
            if (cadena[a] == ' ') {
                cadena[a + 1] = Character.toUpperCase(cadena[a + 1]);
            }
            txtLibro.setText(String.valueOf(cadena));
        }
    }//GEN-LAST:event_txtLibroKeyTyped

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        desbloquear();
        limpiargeneral();
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
    int r = JOptionPane.showOptionDialog(null, "¿Desea salir?",
                "Biblioteca", JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Si",
                    "No"}, "No");
        if (r == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnsalirActionPerformed

    private void cboEditorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboEditorialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboEditorialActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Formulario.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Formulario.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Formulario.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Formulario.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Formulario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnagregar;
    private javax.swing.JButton btnestadistica;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JButton btnsalir;
    private javax.swing.JComboBox<String> cboClase;
    private javax.swing.JComboBox<String> cboEditorial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lblfondo;
    private javax.swing.JLabel lbllibro2;
    private javax.swing.JList<String> lstAño;
    private javax.swing.JList<String> lstClase;
    private javax.swing.JList<String> lstCosto;
    private javax.swing.JList<String> lstEditorial;
    private javax.swing.JList<String> lstEstadisticas;
    private javax.swing.JList<String> lstLibro;
    private javax.swing.JList<String> lstPaginas;
    private javax.swing.JTextField txtAño;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtLibro;
    private javax.swing.JTextField txtPaginas;
    // End of variables declaration//GEN-END:variables
}
